const nsfwmenu = (prefix) => { 
	return `
╔══✪〘 NSFW 〙✪══
║
╰─⊱ *${prefix}randomhentai*
╰─⊱ *${prefix}hentai*
╰─⊱ *${prefix}nsfwblowjob*
╰─⊱ *${prefix}nsfwtrap*
╰─⊱ *${prefix}nsfwneko*
╰─⊱ *${prefix}loli*
╰─⊱ *${prefix}nsfwloli*
╰─⊱ *${prefix}bokep*
╰─⊱ *${prefix}kodenuklir2*
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}cry*
╰─⊱ *${prefix}kiss*
╰─⊱ *${prefix}randomhug*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}kodenuklir*
╰─⊱ *${prefix}nekopoi*
║
╚═〘  ICHI BOT 〙`
}
exports.nsfwmenu = nsfwmenu