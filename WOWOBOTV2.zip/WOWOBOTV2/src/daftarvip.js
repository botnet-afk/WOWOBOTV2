const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 5K > Akses Fitur ViP
-Rp. 10K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6281231971005 atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP BOT :
*_Coming soon_ `
}
exports.daftarvip = daftarvip