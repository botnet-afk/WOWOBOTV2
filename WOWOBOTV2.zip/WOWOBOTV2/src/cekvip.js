const cekvip = () => { 
	return `           
──────────────────
*Nama bot* :   WOWOBOR
──────────────────
        『 *WOWOBOT* 』
──────────────────
• *Status*    : *ACTIVE*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip