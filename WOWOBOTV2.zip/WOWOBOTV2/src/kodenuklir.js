const kodenuklir = () => { 
	return `
	
	*Hi👋👋* *TOBAT BRO ASTAGHFIRULLAH 😌*

Code Nuklear [Doujin Hentai Genre NTR] (Netorare)

Gampang Mode :
• https://nhentai.net/g/316755/
• https://nhentai.net/g/316596/
• https://nhentai.net/g/311850/
• https://nhentai.net/g/315578/
• https://nhentai.net/g/315488/
• https://nhentai.net/g/315406/
• https://nhentai.net/g/315344/
• https://nhentai.net/g/315323/
• https://nhentai.net/g/315136/
• https://nhentai.net/g/315099/

Medium Mode :
• https://nhentai.net/g/316867/
• https://nhentai.net/g/316869/
• https://nhentai.net/g/316785/
• https://nhentai.net/g/316763/51/
• https://nhentai.net/g/316445/
• https://nhentai.net/g/316250/
• https://nhentai.net/g/311283/
• https://nhentai.net/g/265671/
• https://nhentai.net/g/312127/
• https://nhentai.net/g/311560/

Hard Mode :
• https://nhentai.net/g/316820/
• https://nhentai.net/g/316481/
• https://nhentai.net/g/316430/
• https://nhentai.net/g/276347/
• https://nhentai.net/g/196329/
• https://nhentai.net/g/304543/
• https://nhentai.net/g/295295/
• https://nhentai.net/g/311262/
• https://nhentai.net/g/311882/
• https://nhentai.net/g/312180/

Kodeu nuklir ti MILF Oneesan dugi ka bro ***** loli

https://nhentai.net/g/271890/
https://nhentai.net/g/272057/
https://nhentai.net/g/272173/
https://nhentai.net/g/272182/
https://nhentai.net/g/272196/
ht
https://nhentai.net/g/272512/
https://nhentai.net/g/271245/
https://nhentai.net/g/271056/
https://nhentai.net/g/270809/
https://nhentai.net/g/269653/
https://nhentai.net/g/266088/
https://nhentai.net/g/264980/
https://nhentai.net/g/262215/
https://nhentai.net/g/260433/

-

https://nhentai.net/g/260146/
https://nhentai.net/g/256738/
https://nhentai.net/g/272425/
https://nhentai.net/g/272352/
https://nhentai.net/g/272045/
https://nhentai.net/g/272015/
https://nhentai.net/g/271993/
https://nhentai.net/g/271924/
https://nhentai.net/g/271905/
https://nhentai.net/g/271797/

-

https://nhentai.net/g/271760/
https://nhentai.net/g/271717/
https://nhentai.net/g/271726/
https://nhentai.net/g/271667/
https://nhentai.net/g/267352/
https://nhentai.net/g/152968/
https://nhentai.net/g/238876/
https://nhentai.net/g/116395/
https://nhentai.net/g/84809/
https://nhentai.net/g/211656/

-

https://nhentai.net/g/272117/
https://nhentai.net/g/188721/
https://nhentai.net/g/266402/
https://nhentai.net/g/238876/
[8/6 10.48] +62 812-8025-1698: Happy Mother's Day 165310,177978,211759,212643,229540, 250029,211519,256097,163478, 91505, 79280, 260629,128051,121972,261633,172044,119055,208323,149942,161236, 177150,233766,97949,230107 ,175822, 213545,232837,179166,138603,130183, 173543,234642,268015,228293,268893, 239536, yg suka mamah

Random
 257892 226942 236297 216039 221711 245304 166174 175220 244327 191049 220882 244859 227446 259328 259532 259634 259610 259348 258669 256097 118282 260028 260058 259557 259497 122220 260111 260088 259880 258977 260097 259765 259359 260138 259617 107965 197255 260276 260209 260210 260203 191360 191390 248933 257567 227913 211648 210240 260626 259622 257991 213966 260623 149112 257168 198203 114783 220958 244387 243734 223315 118069 136188 260686 241777  260912 142154 119798 261174 258301 256808 169134 220354 260271 261725 261378 252174 261928 114427 187003 147577 249458 157767 224316 175294 258450 233864 236128 261162 174036 187205 210873 193318 110232 199310 193816 220376 193814 193815 219068 220386 177642 188269 181837 220377 119293 257528 258926 262384 105951 259904 208174 249229 245644 262538 234818 216845 149212 134442 135927 262447 261811 261650 261225 261226 260761 250327 192327 167801 150309 123554

 https://www2.zippyshare.com/d/z9dcY6Nr/791216/%5bNekoPoi%5d_Akina_to_Onsen_de_H_Shiyo%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www4.zippyshare.com/d/j7PFLGUY/946757/%5bNekoPoi%5d_Tsuma_ga_Kirei_ni_Natta_Wake_-_02_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www111.zippyshare.com/d/EK5uqIMh/566060/%5bNekoPoi%5d_Megane_no_Megami_-_01_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www109.zippyshare.com/d/2ebALhhS/463654/%5bNekoPoi%5d_Watashi_ga_Toriko_-_02%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www115.zippyshare.com/d/LmzOkRAI/313299/%5bNekoPoi%5d_Chichi-iro_Toiki_-_01_%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www89.zippyshare.com/d/SgEHvrJs/42812/%5bNekoPoi%5d_Chichi-iro_Toiki_-_02_%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www66.zippyshare.com/d/j0ivbciL/520411/%5bNekoPoi%5d_Onna_Maou_Melissa_no_H_na_Boukenki_-_01_%5b360P%5d_%5bnekopoi.care%5d.mp4
 https://www71.zippyshare.com/d/M225YIrR/535656/%5bNekoPoi%5d_Buta_no_Gotoki_Sanzoku_ni_Torawarete_Shojo_wo_Ubawareru_Kyonyuu_Himekishi_Onna_Senshi_-_01%5b360P%5d%5bnekopoi.care%5d.mp4
 https://www49.zippyshare.com/d/bdwYjaXS/605790/%5bNekoPoi%5d_Akebi_no_Hana___Maho_-_01_%5b360P%5d_%5bnekopoi.pro%5d.mp4
 
 ● CODE NUKLIR ●
‌229144 253687 238577 236509
‌227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
‌225496 259137 231681 161688
‌199613 259260 260433 235532 
‌88323 272117 170213 256613
‌258382 224942

/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba 
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ -  Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/  - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ -  Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
/g/35240/ - Eiken Lovers
/g/77415/ - Koinaka
/g/190900/ - Grazero Fantasy
/g/161819/ - Night Of Incest
/g/151132/ - Pet Na Ane No Shitsukekata
/g/147585/ - Anetsun Summer!
/g/136908/ - Man x Koi
/g/112907/ - Imouto x Swimming!
/g/125392/ - Joubutsu!
/g/174463/ - Hotizuma Miyuki-San
/g/159290/ - Mister Mistake
/g/137953/ - Hotondo Byouki
 /g/114053/ - Unknown Title 
 /g/78818/ - Furofuro!
 /g/15055/ - Demodori Mama
 /g/39876/ - Cherry Break
 /g/191427/ - Doutei Danshi Kousei Iinkai
 /g/192695/ - Costte Asobo.
 /g/192330/ - Level 1
 /g/191320/ - Kimi Ni Nara Dekiru
 /g/164434/ - MIDNIGHT PRINCESS
 /g/76813/ - Superior Cake
 /g/148669/ - Ohime-sama Gokko
 /g/144806/ - Youkai Watching
 /g/163698/ - Escalation
 /g/158559/ - Jiyuu de Kimama na Ore no Imouto
 /g/182210/ - Hatsujou Days
 /g/131428/ - Having Fun With The One That I Love
 /g/112853/ - Boku to Oneesan no Naisho
 /g/178594/ - Imouto no Oppai ga Marudashi Datta Hanashi 1
 /g/195665/ - Imouto no Oppai ga Marudashi Datta Hanashi 2
 /g/195092/ - Imouto no Oppai ga Marudashi Datta Hanashi 3
 /g/195093/ - Imouto no Oppai ga Marudashi Datta Hanashi 4
 
 229144 253687 238577 236509
 ‌227675 229085 233245 266177
 254351 265855 239842 219847
 239749 230566 253104 230185
 251974 253091 251489 238030
 260614 245023 232887 233547
 262158 262870 239312 255129
 244530 246963 256050 215459
 243725 233770 250704 261819
 261830 215658 256404 260028
 261789 241254 268580 262407
 262252 201814 250193 236036
 262889 243933 245697 239750
 128983 95364 223815 225080
 110332 225767 97247 231139
 266116 217037 160657 182439
 205089 176495 199121 199425
 184068 186615 224644 129479
 251524 153374 146499 258212
 163532 255244 269825 235914
 247103 138365 124624 219718
 168941 265918 205995 191390
 ‌225496 259137 231681 161688
 ‌199613 259260 260433 235532
 ‌88323 272117 170213 256613
 ‌258382 224942 281261

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ● Milf ●
165310,177978,211759,212643,229540, 250029,211519,256097,163478, 91505, 79280, 260629,128051,121972,261633,172044,119055,208323,149942,161236, 177150,233766,97949,230107 ,175822, 213545,232837,179166,138603,130183, 173543,234642,268015,228293,268893, 239536, yg suka mamah

/g/181556/ - Fudeoro Sisters
/g/152456/ - Mou Teitoku No Soba
/g/167936/ - Inma Mo Mikata
/g/139048/ - shojo soushitsu
/g/185592/ - Gensoukyou Rakuenka Keikaku 11
/g/191427/ - Kousei Iinkai
/g/175015/ - Sister Breeder
/g/142825/ - A Certain Village
/g/182290/ - A hero taken prisoner
/g/192845/ - Toaru Natsu
/g/192849/ - Toaru Fuyu
/g/183099/ - Adolescent calculation
/g/192143/ - Blonde no koigokoro
/g/142825/ - Toaru mura no Fudeoroshi Jijou
/g/153856/ - Tenryuu Onee-chan fo naisho no Yasen Enshuu!!
/g/158404/ - Kusogaki
/g/136026/ - Megaflower x flower
/g/188918/ Kodomo no Ecchi
/g/193876/ - Razoku no Yoru
/g/193984/ - Houkago Rendezvous
/g/76119/ - Broadcast Girlfriend
/g/192874/ - Koyomi Fechi
/g/107180/ - Harem Bukai no Boku
/g/110900/ - Kiniro
/g/135193/ - It's my win!
/g/161488/ - Shota Teitoku to Nyuukyo Time
/g/65433/ - Jirettai no Yo!
/g/182327/ - Sakeno Seiton
/g/78651/ - Harem Time
/g/190230/ - Boku no Bimama
/g/191880/ - Sanae Hamaru
/g/180600/ - Sakaki-san Satisfaction
/g/105465/ - Sakaki-san Franchise
/g/173023/ - Tiny Evil
/g/191049/ - Kono Suba 1
/g/191851/ - Kono Suba 2
/g/167112/ - i'll be your cat
/g/177754/ - Sloppy Sister
/g/187016/ - Nanyou no Vacances Sakusen
/g/165961/ - Love-ridden
/g/165962/ - Pandemonium
/g/97879/ - Natsuyasumi
/g/74500/ - Nee-chan no yobanaide
/g/133435/ - Spirited Girl
/g/152075/ - Trick And Treat
/g/174888/ - Razoku No Yoru
/g/93354/ - Melty Play
/g/74076/ - BAD COMMUNICATION
/g/122948/ - PLAY BACK
/g/104346/ - Funky Glamourous
/g/91773/ - Good Times!!
/g/78226/ - Practice Game
/g/76482/ - JOINT
/g/68508/ - Kimi ga iru nara
/g/61224/ - Way back to the future
/g/60473/ - Hoshi ni negai o
/g/58469/ - Splash
/g/56295/ - Heat Island
/g/53905/ - I Beg You
/g/42383/ - Rumors
/g/187611/ - My Dear Maid
/g/190846/ - Tsukimi Dango
/g/158050/ - Muchimuchi
/g/83269/ - Only a taste for Onee-Chan
/g/146042/ - Bismarck wa Shounen Teitoku kara Seifuku
/g/178941/ - Kodomo-Sensei
/g/100401/ - Sister paradise
/g/35240/ - Eiken Lovers
/g/77415/ - Koinaka
/g/190900/ - Grazero Fantasy
/g/161819/ - Night Of Incest
/g/151132/ - Pet Na Ane No Shitsukekata
/g/147585/ - Anetsun Summer!
/g/136908/ - Man x Koi
/g/112907/ - Imouto x Swimming!
/g/125392/ - Joubutsu!
/g/174463/ - Hotizuma Miyuki-San
/g/159290/ - Mister Mistake
/g/137953/ - Hotondo Byouki
/g/114053/ - Unknown Title 
/g/78818/ - Furofuro!
/g/15055/ - Demodori Mama
/g/39876/ - Cherry Break
/g/191427/ - Doutei Danshi Kousei Iinkai
/g/192695/ - Costte Asobo.
/g/192330/ - Level 1
/g/191320/ - Kimi Ni Nara Dekiru
/g/164434/ - MIDNIGHT PRINCESS
/g/76813/ - Superior Cake
/g/148669/ - Ohime-sama Gokko
/g/144806/ - Youkai Watching
/g/163698/ - Escalation
/g/158559/ - Jiyuu de Kimama na Ore no Imouto
/g/182210/ - Hatsujou Days
/g/131428/ - Having Fun With The One That I Love
/g/112853/ - Boku to Oneesan no Naisho
/g/178594/ - Imouto no Oppai ga Marudashi Datta Hanashi 1
/g/195665/ - Imouto no Oppai ga Marudashi Datta Hanashi 2
/g/195092/ - Imouto no Oppai ga Marudashi Datta Hanashi 3
/g/195093/ - Imouto no Oppai ga Marudashi Datta Hanashi 4
/g/183714/ - Mating With Oni 1
/g/181008/ - Mating With Oni 2
/g/176948/ - Gal Shota Cinderella 1
/g/178511/ - Gal Shota Cinderella 2
/g/185653/ - Gal Shota Cinderella 3
/g/137236/ - Mika-ppoi no! 1
/g/144128/ - Mika-ppoi no! 2
/g/3508/ - Shounen Teikoku 1
/g/3509/ -Shounen Teikoku 2
/g/3510/ - Shounen Teikoku 3
/g/3511/ - Shounen Teikoku 5''
/g/3512/ -Shounen Teikoku 5
/g/3262/ Shounen Teikoku 6
/g/3466/ - Shounen Teikoku 7
/g/2598/ - Shounen Teikoku 8
/g/8196/ - Shounen Teikoku 9
/g/185406/ - Ane Zukushi 1-11
/g/188848/ - Perfect Half (long)
[13/8 17.26] Ordinary Guy: 198964 Countryside 
104436 Mismatched Thoughts
213681 Cultivating Bigger Pleasure
242460 Bokujou: Happy End
255869 Today, Surely
116018 Kahanshin No Otsukiai
165310 Suki Suki! Okaa-san
187047 Shirasaka Koume To No Kankei
116272 Akiko-san To Issho
274000 Hame Kama
93335 Henkano 
165961 Love-Ridden 
250500 Koishi-chan No Bitch Na Hon
264061 Idol Refle Sex
110896 Uchi No Imouto Ga Sukoshi Kawaii
187095 Nuki & Koki
32591 Kosu Tora
151436 FuckBuddy Collection
231188 Minatsu's Fault
275485 Nurunuru Deriheru
275306 Sweet Whispers
205199 Most Distant Neighbor
274796 The Drunk Mouth Of My Neighbor
274412 Kyousei Zecchou Batsu Game
71646 Otonashi Kotorisan
273719 Oshiri Ai
273849 Strength and III
120744 PuniKano
172759 Dogful Days
273337 I Will Serve You Tonight
273132 Watanabe's Day Off
273222 Koukando Analyze!
272129 Dog & Cat Roleplay
271958 Enemy Girl
271892 Poolside Reward
217727 Uruka-chan To Ichaicha Shitai!
271431 Toshoshitsu O Shimete Kara
271282 Hidden Quest
270752 Natsu Ni   Ecc

  ● Random ●
257892 226942 236297 216039 221711 245304 166174 175220 244327 191049 220882 244859 227446 259328 259532 259634 259610 259348 258669 256097 118282 260028 260058 259557 259497 122220 260111 260088 259880 258977 260097 259765 259359 260138 259617 107965 197255 260276 260209 260210 260203 191360 191390 248933 257567 227913 211648 210240 260626 259622 257991 213966 260623 149112 257168 198203 114783 220958 244387 243734 223315 118069 136188 260686 241777  260912 142154 119798 261174 258301 256808 169134 220354 260271 261725 261378 252174 261928 114427 187003 147577 249458 157767 224316 175294 258450 233864 236128 261162 174036 187205 210873 193318 110232 199310 193816 220376 193814 193815 219068 220386 177642 188269 181837 220377 119293 257528 258926 262384 105951 259904 208174 249229 245644 262538 234818 216845 149212 134442 135927 262447 261811 261650 261225 261226 260761 250327 192327 167801 150309 123554
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     ● yg suka onee san ●
189833 12386 232747 186250 200330 63009 202662 66435 145071 6290 185596 121963 67356 157649 230109 243886 172138 126145 253850 144121 166315 197350 2611 19157 247791 239595 50074 1235 135474 258965 262816 195747 242247 252913 149760 139983 114692 151132 152089 144481 201031 169585 198203 240330 236896 88670 254499 169585 196783 194443 59284 249265 62287
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━281917
KUMPULAN KODE NUKLIR
270576
213340
237210/3
184644/
184212/
237987/
238657/
183994/5/
Nhentai.net/g/244044/5/
Nhentai.net/g/183603/
nhentai.net/g/189103/
Nhentai.net/g/183773/8/
Nhentai.net/g/271709/
Nhentai.net/g/271074 Kemonomimi Milf
Nhentai.net/g/270424 Atago Azurlane
Nhentai.net/g/236554 Kemonomimi Half Horse
Nhentai.net/g/238151 kemonomimi final fantasy
Nhentai.net/g/269354 kemono friends
Nhentai.net/g/239567 Cowgirl 
Nhentai.net/g/227556 Bird Girl
Nhentai.net/g/226184 Neko
Nhentai.net/g/225422 Racoon
Nhentai.net/g/268918 Lolikitsune
Nhentai.net/g/235660 Fox
‌229144 253687 238577 236509
‌227675 229085 233245 266177
254351 265855 239842 219847
239749 230566 253104 230185
251974 253091 251489 238030
260614 245023 232887 233547
262158 262870 239312 255129
244530 246963 256050 215459
243725 233770 250704 261819
261830 215658 256404 260028
261789 241254 268580 262407
262252 201814 250193 236036
262889 243933 245697 239750
128983 95364 223815 225080
110332 225767 97247 231139
266116 217037 160657 182439
205089 176495 199121 199425
184068 186615 224644 129479
251524 153374 146499 258212
163532 255244 269825 235914
247103 138365 124624 219718
168941 265918 205995 191390
‌225496 259137 231681 161688
‌199613 259260 260433 235532
‌88323 272117 170213 256613
‌258382 224942
https://nhentai.net/g/192237/ Watashi to
https://nhentai.net/g/134318/ Watashi no Onii-chan 1
https://nhentai.net/g/165279/ Watashi no Onii-chan 2
https://nhentai.net/g/164114/ Watashi no Onii-chan 3
https://nhentai.net/g/192347/ Watashi no Onii-chan 4
https://nhentai.net/g/209026/ Cocologic
https://nhentai.net/g/207432/ Watashi no Onii-chan 4,5
https://nhentai.net/g/247574/ Watashi no Onii-chan Extra


*RIZKYBOT* `
}
exports.kodenuklir = kodenuklir